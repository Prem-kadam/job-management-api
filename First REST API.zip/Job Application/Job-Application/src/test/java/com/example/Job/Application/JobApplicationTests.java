package com.example.Job.Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobApplicationTests {

	@Test
	void contextLoads() {
	}

}
